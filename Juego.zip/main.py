import random
print('ALE: damn the helicopter is falling because of the tornado!')
input()
print('LILI: what should we do we are on a desserted island , we need to get out of here')
input()

print('JUSTIFER: we need to look for clues because i just find out that if you stay here for more than a week you die')
input()

print('ALE: guys i just found an abandoned pyramid')
input()

print('LILI: i found that theres 7 clues all around the island and if you find all of them you have the chance to get out of the island')


print("a:tienen que ir hacia la catedral de la punta")

print("@b:tienen que ir a donde puedes morir pero igual es el lugar mas seguro")

respuesta=input("Choose your path")

if (respuesta=="a"):
  print("moriste vuelve a intentarlo")

if (respuesta=="b"):
  print("escogiste b")

print('JUSTIFER: tenemos que ir hacia la jungla')
input()

print('ALE: aqui hay un mapa de toda la isla tenemos que ir hacia el sur')
input()

print('LILI: ok pero antes hay que organizar lo que vamos a hacer cada quien')
input()

print('elige tu personaje')






print('JUSTIFER: oigan chicos aqui hay como una casa abandonada hay que ver que hay adentro')
input()

print('ALE: si vamos a ver')
input()

print('JUSTIFER: miren encontre un cofre , dice que tenemos que ir o hacia la montaña dorada o hacia el bosque azul')
input()

print('ALE: ok yo siento que tenemos que ir hacia la montaña dorada')
input()

print('LILI: oigan chicos creo que tienen que ver esto!')
input()

print('ALE: corran!')
input()

print('JUSTIFER: no , tenemos que pelear contra ella')
input()

print('elige si pelear o correr')
input()

respuesta2=input()

if (respuesta2=="pelear"):
  print("felicitaciones lograste derrotar el primer monstruo")

if (respuesta2=="correr"):
  print("lograste escapar felicidades")

print('JUSTIFER: hay que ir hacia la montaña')
input()

print('ALE: okok')
input()

print('LILI: ya estamos casi a la mitad chicos hay que seguir hasta llegar')
input()

print('JUSTIFER: vean chicos encontre estas viejas ruinas')
input()

print('ALE: miren encontre esto')
input()

print('LILI: guau esta muy padre , parece que tiene un boton')
input()

print('JUSTIFER: a ver pasamelo para revisarlo')
input()

print('LILI: okok')
input()

print('JUSTIFER *abrio el boton*')
input()

print('TEXTURA DE LA ISLA: hola supervivientes por lo que estamos viendo les esta yendo muy bien espero sigan asi')
input()

print('*se caen a una trampa y se cierra*')
input()

print('ALE: ahora resulta que tambien nos pueden poner trampas')
input()

print('JUSIFER: tiene que haber una salida ')
input()

print('LILI: si siempre hay una salida')
input()

print('ALE: chicos miren lo que encontre')
input()

print('JUSTIFER: a ver?')
input()

print('ALE: es una palanca que abre algo')
input()

print('JUSTIFER: pues girala ')
input()

print('ALE: ya esta vamos a ver que pasa')
input()

print('JUSTIFER: wow miren todo eso')
input()

print('LILI: es puro oro para que nos podria servir')
input()

print('ALE: pues para volvernos ricos cuando regresemos')
input()

print('JUSTIFER: si es que salimos de aqui')
input()

print('LILI: bueno di quieren ponemos lo que aguantemos bien para poder correr en una mochila')
input()

print('JUSTIFER: si quierenpongan todo en mi mochila')
input()

print('LILI: oigan miren lo que viene pongan todo lo que puedan en la mochila')
input()

print('JUSTIFER: CORRAN!')
input()

print('elige la salida 1: salir por donde vinieron 2:salir por el tunel')
input()

respuesta2=input()

if (respuesta2=="tunel"):
  print("estan atrapados y el monstruo vendra pronto encuentren la salida")

if (respuesta2=="salir por donde vinieron"):
  print("estan atrapados tienen que encontrar la salida ")

print('ALE: ok entonces tenemos que encontrar la salida supongo hay que apurarnos')
input()

print('JUSTIFER: acabo de encontar una nota que dice que tenemos que buscar la palanca')
input()

print('LILI: aqui puede que este')
input()

print('JUSTIFER: pues busca')
input()

print('LILI creo que la encontre')
input()

print('JUSTIFER: a ver abrela')
input()

print('LILI: ya esta')
input()

print('ALE: ahi esta ya pudimos salir')
input()

print('JUSTIFER: ok tenemos que seguir con el camino')
input()

print('ALE: pero a donde vamos')
input()

print('LILI: hacia la ciudad perdida')
input()

print('JUSTIFER: ok segun dice el mapa es hacia alla')
input()

print('ALE: ok vanos hacia alla')
input()

print('JUSTIFER: escuchan eso?')
input()

print('LILI: no la verdad no')
input()

print('JUSTIFER: si se escuchan como unos ronquidos')
input()

print('ALE: no no escuchamos nada ')
input()

print('JUSTIFER: vengan las voy a llevar')
input()

print('ALE: a ver te seguimos')
input()

print('LILI: ya lo empece a escuchar')
input()

print('ALE: suena muy fuerte mejor no hay que acercarnos')
input()

print('JUSTIFER: yo si voy a ir a ver que es')
input()

print('LILI: bueno te acompañamos')
input()

print('JUSTIFER: creo que se desperto ya no se escuchan')
input()

print('LILI: viene para aca ')
input()

print('JUSTIFER: es una abeja gigante')
input()

print('ALE: aqui hay un traductor de abejas gigsntes')
input()

print('JUSTIFER: bueno vamos a ver que dice')
input()

print('ALE: aqui dice que si hace tres sonidos es que nos quiere ayudar')
input()

print('JUSTIFER: que mas')
input()

print('ALE: si hace 2 es que hay peligro cerca y nos tenemos que ir')
input()

print('JUSTIFER: que mas')
input()

print('ALE: si hace 1 es que sus amigas nos quieren comer')
input()

print('JUSTIFER: que mas')
input()

print('ALE: ahi acaba')
input()

print('JUSTIFER: ok entonces tenemos un 33% de probabilidad de que nos quiera ayudar')
input()

print('LILI: bueno ha esta muy cerca para que podamos hacer algo')
input()

print(' ABEJA GIGANTE: 3 sonidos')
input()

print('JUSTIFER: uff nos salvamos')
input()

print('ALE: bueno hay que decirle que nos lleve a donde necesitamos ir')
input()

print('JUSTIFER: buena idea')
input()

print('JUSTIFER: hace lenguaje de señas para decirle a la abeja que los lleve')
input()

print('ABEJA GIGANTE: acepta lleverlos')
input()

print('ALE: bueno hay que subirnos y guiarla')
input()

print('JUSTIFER: es hacia el norte de la isla')
input()

for x in range(3):

  dir=input("derecha o izquierda")
  frase=["cuidado casi te caes hazlo mas lento a la proxima","lo hiciste increible","te esta gustando?"]
  
  if(dir=="derecha"):
     print(random.choice(frase))

           
print('hemos llegado')
input()

print('JUSTIFER: hay que buscar la salida de la isla')
input()

print('ALE: ok pues hay que buscar las otras 3 pistas que nos faltan')
input()

print('LILI: ok ')
input()

print('JUSTIFER:Hey aqui hay una puerta pero necesitamos la contradeña')
input()

print('ALE: hay que buscar cosas que tengan algo wue ver con la puerta')
input()

print('JUSTIFER: hay una nota que dice que hay que buscar unos libros')
input()

print('LILI: okok')
input()

print('ALE: aqui hay libros ')
input()

print('LILI:ok hay una palabra que dice BADBOU')
input()

print('JUSTIFER: ok la voy a intentar')
input()

a='x'
while (a!='BADBOU'):
  a=input('enter a password: ')
print('acces guaranteed')

print('JUSTIFER: ok esta bien')
input()

print('LILI: aqui dice que hay que buscar la X marcada en el mapa')
input()

print('hay muchas X en el mapa pero no sabemos cual elegir')
input()

print('vamos a hacer un calculo')

variable=1

if variable==1:
    print("el 1 tiene 33% de probabilidad")


elif variable==2:
     print("el 2 tiene un 33 % de probabilidad")



elif variable==3:
     print("el 3 tiene un 34% de probabilidad")



else:
    print("ok esta bien")


print('LILI ok hay que ir a la X que tiene un 34%')
input()

print('ALE: no hay que ir hacia la segunda de 33%')
input()

print('JUSTIFER: yo digo que a la que dice ale porque es solo un 1% de diferencia')
input()

print('LILI: no yo no voy air a esa')
input()

print('ALE: yo tampoco voy a ir a la tuya')
input()

print('JUSTIFER: dejen de pelearse')
input()

print('LILI: pues que quieres que hagamos')
input()

print('JUSTIFER: tengo una idea')
input()

print('ALE: cual es tu idea')
input()

print('JUSTIFER: jueguen piedra papel o tijera')
input()

print('ALE: y que pasa si gano?')
input()

print('JUSTIFER: pued vamos al la X de la que gane')
input()

print('LILI: ok esta bien')
input()

print('1. piedra 2.papel 3. tijera')
input()

piedra=input()

if (piedra=="tijera"):
  print("haz ganado")

if (piedra=="papel"):
  print("haz ganado ")

print('JUSTIFER: ok ale gano')
input()

print('LILI: bueno vamos a su X')
input()

print('JUSTIFER: alla vamos')
input()

print('JUSTIFER LE HABLA A LA ABEJA')
input()

print('JUSTIFER: le estoy diciendo a donde llevarnos')
input()

print('ALE: hemos llegado')
input()

print('JUSTIFER: ok ahora a donde tenemos que ir')
input()

print('ALE: pues no se por eso es una pista')
input()

print('LILI: miren encontre una nota')
input()

print('JUSTIFER: que dice?')
input()

print('LILI: dice que busquemos la caja fuerte')
input()

print('JUSTIFER: yo voy a buscar en esa casa')
input()

print('ALE: ok nosotras vamos alla')
input()

print('LILI: ya la encontre chicos! pero tenemos que poner una contraseña')
input()

print('JUSTIFER: pues vamos a intentar')
input()

a='x'
while (a!='ISLA'):
  a=input('inserta contraseña: ')
print('acceso garantizado')
while (a=='ISLA'):
  print('el sistema fue hackeado')
input()

print('ALE: hay que leer ue dice la nota')
input()

print('LILI: dice que ya estamos en la parte final que tenemos que encontrar el submarino para salir de aqui')
input()

print('JUSTIFER: pero no dice nada mas?')
input()

print('LILI: dice que hay una pared con un mapa y ahi sale la ubicacion')
input()

print('JUSTIFER: ya la encontre')
input()

print('LILI: esta por donde estabamos hace rato')
input()

print('JUSTIFER: VAMOS!')
input()

print('ALE: hemos llegado')
input()

print('JUSTIFER: alisten todo')
input()

print('LILI: hay un problema tenemos que poner una contraseña')
input()

print('JUSTIFER: intenta con 1234')
input()

a='x'
while (a!='1234'):
  a=input('inserta contraseña: ')
print('acceso garantizado')
while (a=='1234'):
  print('el sistema fue hackeado')
input()

print('JUSTIFER: ESO !!')
input()

print('LILI: porfin')
input()

print('FELICIDADES HAZ ACABADO EL JUEGO!')